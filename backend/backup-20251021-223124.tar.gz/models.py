from sqlalchemy import Column, String, Integer, Text, DateTime, ForeignKey, JSON
from sqlalchemy.sql import func
from database import Base
import uuid

class Company(Base):
    __tablename__ = "companies"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    user_id = Column(String(36), nullable=False, default=lambda: str(uuid.uuid4()))
    created_at = Column(DateTime, default=func.now())

class Job(Base):
    __tablename__ = "jobs"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    company_id = Column(String(36), ForeignKey("companies.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    requirements = Column(JSON)
    status = Column(String(50), default="active")
    created_at = Column(DateTime, default=func.now())

class Candidate(Base):
    __tablename__ = "candidates"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    job_id = Column(String(36), ForeignKey("jobs.id"), nullable=False)
    file_path = Column(String(500))
    parsed_data = Column(JSON)
    score = Column(Integer)
    analysis = Column(JSON)
    status = Column(String(50), default="new")
    created_at = Column(DateTime, default=func.now())
