# backend/main.py - UPDATED
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from middleware.security import limiter, request_id_middleware, security_headers_middleware
from slowapi.errors import RateLimitExceeded

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.middleware("http")(request_id_middleware)
app.middleware("http")(security_headers_middleware)

from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from prometheus_fastapi_instrumentator import Instrumentator
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from config import settings
from database import engine
import logging

# Logging setup
logging.basicConfig(
    level=logging.INFO if settings.DEBUG else logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Sentry setup (tylko jeśli DSN istnieje)
if settings.SENTRY_DSN:
    sentry_sdk.init(
        dsn=settings.SENTRY_DSN,
        integrations=[FastApiIntegration()],
        environment=settings.ENVIRONMENT,
        traces_sample_rate=1.0 if settings.is_development else 0.1,
        send_default_pii=False,
    )
    logger.info("🔍 Sentry monitoring enabled")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/Shutdown events"""
    logger.info(f"🚀 Rekruter AI starting (env: {settings.ENVIRONMENT})...")
    yield
    logger.info("🛑 Shutting down...")
    await engine.dispose()

app = FastAPI(
    title="Rekruter AI",
    version=settings.API_VERSION,
    lifespan=lifespan,
    debug=settings.DEBUG,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.DEBUG else ["https://yourdomain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Prometheus metrics
if settings.is_production or settings.DEBUG:
    Instrumentator().instrument(app).expose(app, endpoint="/metrics")
    logger.info("📊 Prometheus metrics enabled at /metrics")

# Health check
@app.get("/health")
async def health_check():
    from database import check_db_connection
    db_status = await check_db_connection()
    return {
        "status": "healthy",
        "version": settings.API_VERSION,
        "environment": settings.ENVIRONMENT,
        "database": db_status.get("status", "unknown"),
        "features": {
            "multi_agent": settings.USE_MULTI_AGENT,
            "rag": settings.USE_RAG_CONTEXT,
            "kaizen": settings.USE_KAIZEN_LEARNING,
            "redis": settings.redis_available,
        }
    }

# Error handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc) if settings.DEBUG else None}
    )

# Import routers
from routers import jobs, candidates

app.include_router(jobs.router, prefix="/api")
app.include_router(candidates.router, prefix="/api")

@app.get("/")
async def root():
    return {
        "message": "Rekruter AI API",
        "version": settings.API_VERSION,
        "docs": "/docs",
        "health": "/health",
        "metrics": "/metrics"
    }
