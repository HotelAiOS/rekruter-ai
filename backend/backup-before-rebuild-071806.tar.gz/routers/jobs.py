from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import List
from uuid import UUID
from database import get_db
from models import Job, Company, Candidate
from schemas import JobCreate, JobUpdate, JobResponse, JobStats
import logging

router = APIRouter(prefix="/api/jobs", tags=["jobs"])
logger = logging.getLogger(__name__)

@router.post("", response_model=JobResponse, status_code=status.HTTP_201_CREATED)
async def create_job(
    job_data: JobCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create new job posting"""
    try:
        # Get or create test company (will be replaced with auth)
        result = await db.execute(select(Company).limit(1))
        company = result.scalar_one_or_none()
        
        if not company:
            from uuid import uuid4
            company = Company(
                id=uuid4(),
                name="Test Company",
                user_id=uuid4()
            )
            db.add(company)
            await db.flush()
        
        job = Job(
            company_id=company.id,
            title=job_data.title,
            description=job_data.description,
            requirements=job_data.requirements.dict() if hasattr(job_data.requirements, 'dict') else job_data.requirements
        )
        db.add(job)
        await db.commit()
        await db.refresh(job)
        
        return job
    except Exception as e:
        await db.rollback()
        logger.error(f"Error creating job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("", response_model=List[JobResponse])
async def list_jobs(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    status_filter: str = Query(None, alias="status"),
    db: AsyncSession = Depends(get_db)
):
    """List all jobs with pagination"""
    try:
        query = select(Job)
        
        if status_filter:
            query = query.where(Job.status == status_filter)
        
        query = query.offset(skip).limit(limit)
        result = await db.execute(query)
        jobs = result.scalars().all()
        
        return jobs
    except Exception as e:
        logger.error(f"Error listing jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{job_id}", response_model=JobResponse)
async def get_job(
    job_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get single job by ID"""
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    return job

@router.put("/{job_id}", response_model=JobResponse)
async def update_job(
    job_id: UUID,
    job_data: JobUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update existing job"""
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    update_data = job_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        if field == "requirements" and hasattr(value, 'dict'):
            value = value.dict()
        setattr(job, field, value)
    
    await db.commit()
    await db.refresh(job)
    
    return job

@router.delete("/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_job(
    job_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete job (soft delete - set status to 'closed')"""
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job.status = "closed"
    await db.commit()
    
    return None

@router.get("/{job_id}/stats", response_model=JobStats)
async def get_job_stats(
    job_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get job statistics (candidates count, avg score, etc)"""
    # Check if job exists
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Get candidates statistics
    stats_query = select(
        func.count(Candidate.id).label('total_candidates'),
        func.avg(Candidate.score).label('avg_score'),
        func.max(Candidate.score).label('max_score'),
        func.min(Candidate.score).label('min_score')
    ).where(Candidate.job_id == job_id)
    
    stats_result = await db.execute(stats_query)
    stats = stats_result.one()
    
    # Count by status
    status_query = select(
        Candidate.status,
        func.count(Candidate.id).label('count')
    ).where(Candidate.job_id == job_id).group_by(Candidate.status)
    
    status_result = await db.execute(status_query)
    status_counts = {row.status: row.count for row in status_result}
    
    return {
        "job_id": job_id,
        "total_candidates": stats.total_candidates or 0,
        "avg_score": float(stats.avg_score) if stats.avg_score else 0.0,
        "max_score": float(stats.max_score) if stats.max_score else 0.0,
        "min_score": float(stats.min_score) if stats.min_score else 0.0,
        "candidates_by_status": status_counts
    }
